self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "73b5737227823a4d5ef0ee58c6f470c5",
    "url": "/index.html"
  },
  {
    "revision": "f2627742f35fcf74ce3e",
    "url": "/static/css/2.35fcc229.chunk.css"
  },
  {
    "revision": "64feb8a568fec7c0c03e",
    "url": "/static/css/main.5a6b043f.chunk.css"
  },
  {
    "revision": "f2627742f35fcf74ce3e",
    "url": "/static/js/2.188f5f04.chunk.js"
  },
  {
    "revision": "3453b8997016469371284a28c0e873e2",
    "url": "/static/js/2.188f5f04.chunk.js.LICENSE.txt"
  },
  {
    "revision": "64feb8a568fec7c0c03e",
    "url": "/static/js/main.5026bad6.chunk.js"
  },
  {
    "revision": "2d28592c0c3cccc2cfdd",
    "url": "/static/js/runtime-main.126801b3.js"
  },
  {
    "revision": "dbb76c9123f70ad9c0c5df892b4b15b8",
    "url": "/static/media/logo.dbb76c91.png"
  }
]);